
close all; clear all; 
addpath('Rice_Wavelet_Toolbox_2.4');
rand('state',0); randn('state',0);
F = double(imread('pics/3DMR_Chest.jpg'));
F=imresize(F, [256 256]);
F=im256(F);  figure; imshow(F, [])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Preparing the data and operators
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for ii=1:3
[m n] = size(F); N = m*n;f = F(:);d = 4;   %%%% choose 3, 4, 
[OMEGA] = RandMask_rect(double(m/d),double(n/d),m,n);
% Number of projections
k = length(OMEGA);
[mask] = RandMask_InverseTransfer(OMEGA,m,n); 
% partial FFT tranform
R = @(x) A_fhp_rect(x, OMEGA, m, n);
RT = @(x) At_fhp_rect(x, OMEGA, m, n);
% define the function handles that compute 
% the products by W (inverse DWT) and W' (DWT)
wav = daubcqf(2);W = @(x) midwt(x,wav);WT = @(x) mdwt(x,wav);
AO = @(x) R(W(x)); AOT = @(x) WT(RT(x)); 
A = A_operator(@(x) AO(x), @(x) AOT(x));
Phi = A_operator(@(x) WT(x), @(x) W(x));    % notice Phi=WT
RR = A_operator(@(x) R(x), @(x) RT(x));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sigma = 0.01; noise = sigma*randn(2*k+1,1); b = R(f) + noise;
data = zeros(m,n);data(1,1) = b(1); KK = length(b);
data(OMEGA) = b(2:(KK+1)/2) + i*b((KK+3)/2:KK);
im_poc = real(ifft2(data))*sqrt(m*n);
alpha = 1e-3; beta = 3.5e-2; 
xs = WT(f);input.f=f; input.xs=xs;
input.n1=m;input.n2=n;
input.alpha=alpha;input.beta=beta;
input.A=A;input.Phi=Phi;input.b=b;
input.maxitr=500;input.maxiitr= 500;
input.stopCriterion=2; 
input.tolA=1e-8; input.no=50; %%%%  Change no for different iteration numbers
input.L=1;input.num=1; 
input.l=0; input.u=255;
input2=input; input2.A=RR;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% SparseMRI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
input1=input;
FT = p2DFT(mask, [m n], 1, 2);im_ori=F; 
input1.alpha=input1.alpha*2; 	% Weight for TV penalty
input1.beta=input1.beta*2;	% Weight for Transform L1 penalty
input1.maxIter=8;input1.num=1;
input1.mask=mask; input1.im_ori = im_ori;
noise=randn(m, n); noise(find(mask==0))=0;
input1.data =  FT*(im_ori)+sigma*noise;
input1.im_dc=im_poc; 
fprintf('calling the function SparseMRI.....\n');

out=sparseMRICg(input1); out1=out; im1=abs(out.im_recover);

out.fobjTrace=out.fobjTrace/2;
fprintf(1,'Iter_time = %.2fsec, Iteration Num = %d, snr = %f \n',out.timeTrace(end),input1.maxIter, out.snrTrace(end));
fprintf(1,'k = %d, samp.ratio = %f, func.value = %f\n\n',k, k/(m*n),out.fobjTrace(end));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% TVCMRI  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('calling the function TVCMRI.....\n');

out = TVCMRI(input);

out2=out; x = out.x; im2=Phi'*x; im2=reshape(im2, [m, n]);
fprintf(1,'Iter_time = %.2fsec, Iteration Num = %d, snr = %f \n',out.iter_time, input.no, out.snr(end));
fprintf(1,'k = %d, rec_err = %10.6e, samp.ratio = %f, func.value = %f\n\n',k, norm(x-xs)/norm(xs),k/(m*n),out.funv(end));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% RecPF  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('calling the function RecPF.....\n');
opts.maxItr = input.no; opts.gamma = 1.6;opts.beta = 10;
opts.relchg_tol = 5e-4; opts.real_sol = true; 
opts.normalize = false; 
FB = fft2(F)/sqrt(m*n);
bb=FB(OMEGA)+1*randn(length(OMEGA), 1); 
pick=false(m,n);pick(OMEGA)=true;

[U,out] = RecPF(m,n,input.alpha,input.beta,pick,bb,2,opts,WT,W,range(F(:)),F);

out3=out; im3 = U; x=Phi*U(:);
fprintf(1,'Iter_time = %.2fsec, Iteration Num = %d, snr = %f \n',out.xtime(end), out.iter, out.snr(end));
fprintf(1,'k = %d, rec_err = %10.6e, samp.ratio = %f, func.value = %f\n\n', k, norm(x-xs)/norm(xs),k/(m*n),out.funv(end));
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%% CSA  
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('calling the function TV_CSA.....\n');

out = TVS_CSAy(input2);

out4=out; im4 = out.y; x=Phi*im4; im4=reshape(im4, [m, n]);
fprintf(1,'Iter_time = %.2fsec, Iteration Num = %d, snr = %f \n',out.xtime(end), input.no, out.snr(end));
fprintf(1,'k = %d, rec_err = %10.6e, samp.ratio = %f, func.value = %f\n\n',k, norm(x-xs)/norm(xs),k/(m*n),out.funv(end));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% FCSA  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('calling the function TV_FCSA.....\n');

out = TVS_FCSAy(input2);

out5=out;im5 = out.y; x=Phi*im5; im5=reshape(im5, [m, n]);
fprintf(1,'Iter_time = %.2fsec, Iteration Num = %d, snr = %f \n',out.xtime(end), input.no, out.snr(end));
fprintf(1,'k = %d, rec_err = %10.6e, samp.ratio = %f, func.value = %f\n\n',...
    k, norm(x-xs)/norm(xs),k/(m*n),out.funv(end));


SNR1(:,ii,1)=out1.snrTrace; 
SNR(:,ii,2)=out2.snr; SNR(:,ii,3)=out3.snr; 
SNR(:,ii,4)=out4.snr; SNR(:,ii,5)=out5.snr;

Time1(:,ii,1)=out1.timeTrace; 
Time(:,ii,2)=out2.xtime; Time(:,ii,3)=out3.xtime; 
Time(:,ii,4)=out4.xtime; Time(:,ii,5)=out5.xtime;

Object1(:,ii,1)=out1.fobjTrace; 
Object(:,ii,2)=out2.funv; Object(:,ii,3)=out3.funv; 
Object(:,ii,4)=out4.funv; Object(:,ii,5)=out5.funv;

Rate(:,ii,2)=out2.xrate; Rate(:,ii,3)=out3.xrate; 
Rate(:,ii,4)=out4.xrate; Rate(:,ii,5)=out5.xrate;


end
SNR_M(:,:)=mean(SNR, 2); SNR_S(:,:)=std(SNR, 0, 2);
Time_M(:,:)=mean(Time, 2); Time_S(:,:)=std(Time, 0, 2);
Object_M(:,:)=mean(Object, 2); Object_S(:,:)=std(Object, 0, 2);
Rate_M(:,:)=mean(Rate, 2); Rate_S(:,:)=std(Rate, 0, 2);

SNR_M1(:,1)=mean(SNR1, 2); SNR_S1(:,1)=std(SNR1, 0, 2);
Time_M1(:,1)=mean(Time1, 2); Time_S1(:,1)=std(Time1, 0, 2);
Object_M1(:,1)=mean(Object1, 2); Object_S1(:,1)=std(Object1, 0, 2);

save SNR SNR; save Time Time; save Object Object; save Rate Rate;
no1=3; no2=0;
num=size(SNR_M,1);
start=1;


figure; hold on;
plot(Time_M1(:,1), SNR_M1(:,1), 'b:', 'linewidth', no1);
plot(Time_M(start:num,2), SNR_M(start:num,2), 'g-.', 'linewidth', no1);
plot(Time_M(start:num,3), SNR_M(start:num,3), 'm--', 'linewidth', no1);
plot(Time_M(start:num,4), SNR_M(start:num,4), 'k-.', 'linewidth', no1);
plot(Time_M(start:num,5), SNR_M(start:num,5), 'r-', 'linewidth', no1);
xlabel('CPU Time (s)');ylabel('SNR');box on;
legend('CG', 'TVCMRI', 'RecPF ', 'CSA', 'FCSA', 'Location','SouthEast');
textobj = findobj('type', 'text');
set(textobj, 'fontsize', 16);
h_xlabel = get(gca,'XLabel');
set(h_xlabel,'FontSize',16); 
h_xlabel = get(gca,'YLabel');
set(h_xlabel,'FontSize',16); 