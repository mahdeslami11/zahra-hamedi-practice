%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all; clear all; 
addpath('Rice_Wavelet_Toolbox_2.4');
rand('state',0); randn('state',0);
% F = double(imread('pics/Heart.png'));
F = double(imread('C:\Users\User\Desktop\5655486\FCSA_MRI1.0\pics\MRI_Coronal_Brain.jpg'));
% F = double(imread('pics/3DMR_Chest.jpg'));
% F = double(imread('pics/3DMR_Renal_Arteries.jpg'));
F=imresize(F, [256 256]);
% F=im256(F);  figure; imshow(F, [])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Preparing the data and operators
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[m n] = size(F); N = m*n;f = F(:);d = 4.4;   %%%% choose 3, 4, 
[OMEGA] = RandMask_rect(double(m/d),double(n/d),m,n);
% Number of projections
k = length(OMEGA);
[mask] = RandMask_InverseTransfer(OMEGA,m,n); 
% partial FFT tranform
R = @(x) A_fhp_rect(x, OMEGA, m, n);
RT = @(x) At_fhp_rect(x, OMEGA, m, n);
% define the function handles that compute 
% the products by W (inverse DWT) and W' (DWT)
wav = daubcqf(2);W = @(x) midwt(x,wav);WT = @(x) mdwt(x,wav);
AO = @(x) R(W(x)); AOT = @(x) WT(RT(x)); 
A = A_operator(@(x) AO(x), @(x) AOT(x));
Phi = A_operator(@(x) WT(x), @(x) W(x));    % notice Phi=WT
RR = A_operator(@(x) R(x), @(x) RT(x));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sigma = 0.01; noise = sigma*randn(2*k+1,1); b = R(f) + noise;
data = zeros(m,n);data(1,1) = b(1); KK = length(b);
data(OMEGA) = b(2:(KK+1)/2) + i*b((KK+3)/2:KK);
im_poc = real(ifft2(data))*sqrt(m*n);
alpha = 1e-3; beta = 3.5e-2; 
xs = WT(f);input.f=f; input.xs=xs;
input.n1=m;input.n2=n;
input.alpha=alpha;input.beta=beta;
input.A=A;input.Phi=Phi;input.b=b;
input.maxitr=500;input.maxiitr= 500;
input.stopCriterion=2; 
input.tolA=1e-8; input.no=50; %%%%  Change no for different iteration numbers
input.L=1;input.num=1; 
% input.l=-inf; input.u=inf;
input.l=0; input.u=255;
input2=input; input2.A=RR;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% SparseMRI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
input1=input;
FT = p2DFT(mask, [m n], 1, 2);im_ori=F; 
input1.alpha=input1.alpha*2; 	% Weight for TV penalty
input1.beta=input1.beta*2;	% Weight for Transform L1 penalty
input1.maxIter=8;input1.num=1;
input1.mask=mask; input1.im_ori = im_ori;
noise=randn(m, n); noise(find(mask==0))=0;
input1.data =  FT*(im_ori)+sigma*noise;
input1.im_dc=im_poc; 
fprintf('calling the function SparseMRI.....\n');

out=sparseMRICg(input1); out1=out; im1=abs(out.im_recover);

out.fobjTrace=out.fobjTrace/2;
fprintf(1,'Iter_time = %.2fsec, Iteration Num = %d, snr = %f \n',out.timeTrace(end),input1.maxIter, out.snrTrace(end));
fprintf(1,'k = %d, samp.ratio = %f, func.value = %f\n\n',k, k/(m*n),out.fobjTrace(end));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% TVCMRI  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('calling the function TVCMRI.....\n');

out = TVCMRI(input);

out2=out; x = out.x; im2=Phi'*x; im2=reshape(im2, [m, n]);
fprintf(1,'Iter_time = %.2fsec, Iteration Num = %d, snr = %f \n',out.iter_time, input.no, out.snr(end));
fprintf(1,'k = %d, rec_err = %10.6e, samp.ratio = %f, func.value = %f\n\n',k, norm(x-xs)/norm(xs),k/(m*n),out.funv(end));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% RecPF  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('calling the function RecPF.....\n');
opts.maxItr = input.no; opts.gamma = 1.6;opts.beta = 10;
opts.relchg_tol = 5e-4; opts.real_sol = true; 
opts.normalize = false; 
FB = fft2(F)/sqrt(m*n);
bb=FB(OMEGA)+1*randn(length(OMEGA), 1); 
pick=false(m,n);pick(OMEGA)=true;

[U,out] = RecPF(m,n,input.alpha,input.beta,pick,bb,2,opts,WT,W,range(F(:)),F);

out3=out; im3 = U; x=Phi*U(:);
fprintf(1,'Iter_time = %.2fsec, Iteration Num = %d, snr = %f \n',out.xtime(end), out.iter, out.snr(end));
fprintf(1,'k = %d, rec_err = %10.6e, samp.ratio = %f, func.value = %f\n\n', k, norm(x-xs)/norm(xs),k/(m*n),out.funv(end));
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%% CSA  
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('calling the function TV_CSA.....\n');

out = TVS_CSAy(input2);

out4=out; im4 = out.y; x=Phi*im4; im4=reshape(im4, [m, n]);
fprintf(1,'Iter_time = %.2fsec, Iteration Num = %d, snr = %f \n',out.xtime(end), input.no, out.snr(end));
fprintf(1,'k = %d, rec_err = %10.6e, samp.ratio = %f, func.value = %f\n\n',k, norm(x-xs)/norm(xs),k/(m*n),out.funv(end));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% FCSA  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('calling the function TV_FCSA.....\n');

out = TVS_FCSAy(input2);

out5=out;im5 = out.y; x=Phi*im5; im5=reshape(im5, [m, n]);
fprintf(1,'Iter_time = %.2fsec, Iteration Num = %d, snr = %f \n',out.xtime(end), input.no, out.snr(end));
fprintf(1,'k = %d, rec_err = %10.6e, samp.ratio = %f, func.value = %f\n\n',...
    k, norm(x-xs)/norm(xs),k/(m*n),out.funv(end));


figure; subplot(2,3,1); imshow(F, []); title('Original');
subplot(2,3,2); imshow(im2, []); title('CG');
subplot(2,3,3); imshow(im2, []); title('TVCMRI');
subplot(2,3,4); imshow(im3, []); title('RecPF');
subplot(2,3,5); imshow(im4, []); title('CSA')
subplot(2,3,6); imshow(im5, []); title('FCSA')

% figure; imshow(F, []); 
% figure; imshow(mask, []);
% figure; imshow(im1, []); 
% figure; imshow(im2, []); 
% figure; imshow(im3, []); 
% figure; imshow(im4, []); 
% figure; imshow(im5, []); 
