function Y = identityPhi(X,trans)
    Y = X;