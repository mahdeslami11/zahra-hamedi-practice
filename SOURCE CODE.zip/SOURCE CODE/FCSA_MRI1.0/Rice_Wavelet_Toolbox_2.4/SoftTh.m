function  x = SoftTh(y,thld)
%    x = SoftTh(y,thld); 
%

%

x = abs(y);
x = sign(y).*(x >= thld).*(x - thld); 
